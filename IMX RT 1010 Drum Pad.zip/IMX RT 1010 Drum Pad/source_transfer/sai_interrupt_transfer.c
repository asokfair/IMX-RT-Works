/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_sai.h"
#include "music.h"
#include "afe_shield.h"
#include "fsl_codec_common.h"

#include "fsl_wm8960.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_codec_adapter.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
/* SAI instance and clock */
#define DEMO_CODEC_WM8960
#define DEMO_SAI SAI1
#define DEMO_SAI_CHANNEL (0)
#define DEMO_SAI_BITWIDTH (kSAI_WordWidth16bits)
//#define DEMO_SAI_IRQ SAI1_IRQn
//#define SAI_TxIRQHandler SAI1_IRQHandler

/* Select Audio/Video PLL (786.48 MHz) as sai1 clock source */
#define DEMO_SAI1_CLOCK_SOURCE_SELECT (2U)
/* Clock pre divider for sai1 clock source */
#define DEMO_SAI1_CLOCK_SOURCE_PRE_DIVIDER (0U)
/* Clock divider for sai1 clock source */
#define DEMO_SAI1_CLOCK_SOURCE_DIVIDER (63U)
/* Get frequency of sai1 clock */
#define DEMO_SAI_CLK_FREQ                                                        \
    (CLOCK_GetFreq(kCLOCK_AudioPllClk) / (DEMO_SAI1_CLOCK_SOURCE_DIVIDER + 1U) / \
     (DEMO_SAI1_CLOCK_SOURCE_PRE_DIVIDER + 1U))

/* I2C instance and clock */
#define DEMO_I2C LPI2C1

/* Select USB1 PLL (480 MHz) as master lpi2c clock source */
#define DEMO_LPI2C_CLOCK_SOURCE_SELECT (0U)
/* Clock divider for master lpi2c clock source */
#define DEMO_LPI2C_CLOCK_SOURCE_DIVIDER (5U)
/* Get frequency of lpi2c clock */
#define DEMO_I2C_CLK_FREQ ((CLOCK_GetFreq(kCLOCK_Usb1PllClk) / 8) / (DEMO_LPI2C_CLOCK_SOURCE_DIVIDER + 1U))

#define OVER_SAMPLE_RATE (384U)

#define DEMO_AUDIO_SAMPLE_RATE (kSAI_SampleRate16KHz)

#if (defined FSL_FEATURE_SAI_HAS_MCLKDIV_REGISTER && FSL_FEATURE_SAI_HAS_MCLKDIV_REGISTER) || \
    (defined FSL_FEATURE_PCC_HAS_SAI_DIVIDER && FSL_FEATURE_PCC_HAS_SAI_DIVIDER)
#define DEMO_AUDIO_MASTER_CLOCK OVER_SAMPLE_RATE *DEMO_AUDIO_SAMPLE_RATE
#else
#define DEMO_AUDIO_MASTER_CLOCK DEMO_SAI_CLK_FREQ
#endif
/* demo audio data channel */
#define DEMO_AUDIO_DATA_CHANNEL (2U)
/* demo audio bit width */
#define DEMO_AUDIO_BIT_WIDTH kSAI_WordWidth16bits
/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
sai_handle_t txHandle           = {0};
static volatile bool isFinished = false;
extern codec_config_t boardCodecConfig;
#if (defined(FSL_FEATURE_SAI_HAS_MCR) && (FSL_FEATURE_SAI_HAS_MCR)) || \
    (defined(FSL_FEATURE_SAI_HAS_MCLKDIV_REGISTER) && (FSL_FEATURE_SAI_HAS_MCLKDIV_REGISTER))
sai_master_clock_t mclkConfig = {
#if defined(FSL_FEATURE_SAI_HAS_MCR) && (FSL_FEATURE_SAI_HAS_MCR)
    .mclkOutputEnable = true,
#if !(defined(FSL_FEATURE_SAI_HAS_NO_MCR_MICS) && (FSL_FEATURE_SAI_HAS_NO_MCR_MICS))
    .mclkSource = kSAI_MclkSourceSysclk,
#endif
#endif
};
#endif
codec_handle_t codecHandle;
volatile uint8_t drum_play=1;
volatile uint32_t sample_count=0;
volatile uint32_t sample_count_inv=0;
volatile uint8_t capbutton_value;
volatile uint8_t swbutton_value;
volatile uint32_t pot_value;
volatile uint8_t capbutton_prev_value;
volatile uint8_t drum_array=0;
/*******************************************************************************
 * Code
 ******************************************************************************/
wm8960_config_t wm8960Config = {
    .i2cConfig = {.codecI2CInstance = BOARD_CODEC_I2C_INSTANCE, .codecI2CSourceClock = BOARD_CODEC_I2C_CLOCK_FREQ},
    .route     = kWM8960_RoutePlaybackandRecord,
    .rightInputSource = kWM8960_InputDifferentialMicInput2,
    .playSource       = kWM8960_PlaySourceDAC,
    .slaveAddress     = WM8960_I2C_ADDR,
    .bus              = kWM8960_BusI2S,
    .format = {.mclk_HZ = 6144000U, .sampleRate = kWM8960_AudioSampleRate16KHz, .bitWidth = kWM8960_AudioBitWidth16bit},
    .master_slave = false,
};
codec_config_t boardCodecConfig = {.codecDevType = kCODEC_WM8960, .codecDevConfig = &wm8960Config};
/*
 * AUDIO PLL setting: Frequency = Fref * (DIV_SELECT + NUM / DENOM)
 *                              = 24 * (32 + 77/100)
 *                              = 786.48 MHz
 */
const clock_audio_pll_config_t audioPllConfig = {
    .loopDivider = 32,  /* PLL loop divider. Valid range for DIV_SELECT divider value: 27~54. */
    .postDivider = 1,   /* Divider after the PLL, should only be 1, 2, 4, 8, 16. */
    .numerator   = 77,  /* 30 bit numerator of fractional loop divider. */
    .denominator = 100, /* 30 bit denominator of fractional loop divider */
};
static void Delay(uint32_t dly){

	while(dly--);
}

void BOARD_EnableSaiMclkOutput(bool enable)
{
    if (enable)
    {
        IOMUXC_GPR->GPR1 |= IOMUXC_GPR_GPR1_SAI1_MCLK_DIR_MASK;
    }
    else
    {
        IOMUXC_GPR->GPR1 &= (~IOMUXC_GPR_GPR1_SAI1_MCLK_DIR_MASK);
    }
}

static void callback(I2S_Type *base, sai_handle_t *handle, status_t status, void *userData)
{
    isFinished = true;
}

/*!
 * @brief Main function
 */
int main(void)
{
    sai_transfer_t xfer;
    uint32_t temp = 0;
    sai_transceiver_t config;

    BOARD_ConfigMPU();
    BOARD_InitPins();
    BOARD_BootClockRUN();
    CLOCK_InitAudioPll(&audioPllConfig);
    BOARD_InitDebugConsole();

    /*Clock setting for LPI2C*/
    CLOCK_SetMux(kCLOCK_Lpi2cMux, DEMO_LPI2C_CLOCK_SOURCE_SELECT);
    CLOCK_SetDiv(kCLOCK_Lpi2cDiv, DEMO_LPI2C_CLOCK_SOURCE_DIVIDER);

    /*Clock setting for SAI1*/
    CLOCK_SetMux(kCLOCK_Sai1Mux, DEMO_SAI1_CLOCK_SOURCE_SELECT);
    CLOCK_SetDiv(kCLOCK_Sai1PreDiv, DEMO_SAI1_CLOCK_SOURCE_PRE_DIVIDER);
    CLOCK_SetDiv(kCLOCK_Sai1Div, DEMO_SAI1_CLOCK_SOURCE_DIVIDER);

    /*Enable MCLK clock*/
    BOARD_EnableSaiMclkOutput(true);

    PRINTF("SAI example started!\n\r");

      I2C_Init();
      OLED_Init();

      OLED_Clear_Screen();

      OLED_PrintLargeText(1,16, "DRUM KIT");
      OLED_PrintText(5,10, "1- DRUM CLASIC");
      OLED_PrintText(6,10, "2- DRUM ASIAN");
      OLED_PrintText(7,10, "3- DRUM MODERN");
    /* SAI init */
    SAI_Init(DEMO_SAI);
    SAI_TransferTxCreateHandle(DEMO_SAI, &txHandle, callback, NULL);
    /* I2S mode configurations */
    SAI_GetClassicI2SConfig(&config, DEMO_AUDIO_BIT_WIDTH, kSAI_Stereo, kSAI_Channel0Mask);
    SAI_TransferTxSetConfig(DEMO_SAI, &txHandle, &config);

    /* set bit clock divider */
    SAI_TxSetBitClockRate(DEMO_SAI, DEMO_AUDIO_MASTER_CLOCK, DEMO_AUDIO_SAMPLE_RATE, DEMO_AUDIO_BIT_WIDTH,
                          DEMO_AUDIO_DATA_CHANNEL);

    /* master clock configurations */
#if (defined(FSL_FEATURE_SAI_HAS_MCR) && (FSL_FEATURE_SAI_HAS_MCR)) || \
    (defined(FSL_FEATURE_SAI_HAS_MCLKDIV_REGISTER) && (FSL_FEATURE_SAI_HAS_MCLKDIV_REGISTER))
#if defined(FSL_FEATURE_SAI_HAS_MCLKDIV_REGISTER) && (FSL_FEATURE_SAI_HAS_MCLKDIV_REGISTER)
    mclkConfig.mclkHz          = DEMO_AUDIO_MASTER_CLOCK;
    mclkConfig.mclkSourceClkHz = DEMO_SAI_CLK_FREQ;
#endif
    SAI_SetMasterClockConfig(DEMO_SAI, &mclkConfig);
#endif

    /* Use default setting to init codec */
    CODEC_Init(&codecHandle, &boardCodecConfig);
    while (1)
    {

		AFE_ReadData();

		if(swbutton_value ==1 ){

			drum_array++;

			Delay(20000);
			if(drum_array>2) drum_array=0;
			Delay(20000);
		}

		PRINTF("CapSense CT Value= %d\n\r",capbutton_value);
	    PRINTF("CapSense PV Value= %d\n\r",capbutton_prev_value);

    	if(capbutton_value==0){

       	//	 OLED_PrintLargeText(3,50, "  ");
    	}

    	if((capbutton_value != capbutton_prev_value) && (capbutton_value!=0)){
    		sample_count=0;
    		drum_play=1;
    	}

    	if((capbutton_value == capbutton_prev_value) && (capbutton_value!=0)){
    		sample_count++;
    		if(sample_count>24){
    			drum_play=1;
    			sample_count=0;
    		}
    	}

    	if(capbutton_value==8 && drum_play){

    		// OLED_PrintLargeText(3,50, "SA");
  			/*  xfer structure */
    			switch(drum_array){


    			case 0:
     				temp          = (uint32_t)drum_snare14;
     				xfer.data     = (uint8_t *)temp;
     				xfer.dataSize = DRUM_SNARE14_LEN;
    				break;
    			case 1:
     				temp          = (uint32_t)drum_snare39;
     				xfer.data     = (uint8_t *)temp;
     				xfer.dataSize = DRUM_SNARE39_LEN;
    				break;
    			case 2:
     				temp          = (uint32_t)drum_ride3;
     				xfer.data     = (uint8_t *)temp;
     				xfer.dataSize = DRUM_RIDE3_LEN;
    				break;

    			}


 				SAI_TransferSendNonBlocking(DEMO_SAI, &txHandle, &xfer);
 				/* Wait until finished */
 				while (isFinished != true)
 				{
 				}
 				isFinished=false;
 			 capbutton_prev_value = capbutton_value;
 			 drum_play=0;
    	}

    	if(capbutton_value==4 && drum_play){

    		// OLED_PrintLargeText(3,50, "RE");
 			/*  xfer structure */
			switch(drum_array){


			case 0:
 				temp          = (uint32_t)drum_kicks11;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_KICKS11_LEN;
				break;
			case 1:
 				temp          = (uint32_t)drum_tom4;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_TOM4_LEN;
				break;
			case 2:
 				temp          = (uint32_t)drum_kicks11;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_KICKS11_LEN;
				break;

			}
				SAI_TransferSendNonBlocking(DEMO_SAI, &txHandle, &xfer);
				/* Wait until finished */
				while (isFinished != true)
				{
				}
				isFinished=false;
			 capbutton_prev_value = capbutton_value;
    		 drum_play=0;
    	}

    	if(capbutton_value==2 && drum_play){
    		// OLED_PrintLargeText(3,50, "GA");
			switch(drum_array){


			case 0:
 				temp          = (uint32_t)drum_conga4;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_CONGA4_LEN;
				break;
			case 1:
 				temp          = (uint32_t)drum_maracas1;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_MARACAS1_LEN;
				break;
			case 2:
 				temp          = (uint32_t)drum_cowbell4;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_COWBELL4_LEN;
				break;

			}
				SAI_TransferSendNonBlocking(DEMO_SAI, &txHandle, &xfer);
				/* Wait until finished */
				while (isFinished != true)
				{
				}
				isFinished=false;
				capbutton_prev_value = capbutton_value;
				drum_play=0;
    	}

    	if(capbutton_value==1 && drum_play){
    		// OLED_PrintLargeText(3,50, "MA");
			switch(drum_array){


			case 0:
 				temp          = (uint32_t)drum_hit01;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_HIT1_LEN;
				break;
			case 1:
 				temp          = (uint32_t)drum_cowbell1;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_COWBELL1_LEN;
				break;
			case 2:
 				temp          = (uint32_t)drum_stick1;
 				xfer.data     = (uint8_t *)temp;
 				xfer.dataSize = DRUM_STICK1_LEN;
				break;

			}
			SAI_TransferSendNonBlocking(DEMO_SAI, &txHandle, &xfer);
			/* Wait until finished */
			while (isFinished != true)
			{
			}
			capbutton_prev_value = capbutton_value;
			drum_play=0;
			isFinished=false;

    	}


    }
}
